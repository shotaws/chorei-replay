function getDataValues(sheet: GoogleAppsScript.Spreadsheet.Sheet, targetColumn: number): string[] {
  const dataRange = sheet.getDataRange();
  const lastRow = dataRange.getLastRow();
  const values: string[] = [];

  for (let row = 1; row <= lastRow; row++) {
    const value = sheet.getRange(row, targetColumn).getValue().toString();
    values.push(value);
  }

  return values;
}

function validateCellContents(): void {
  const sheet = SpreadsheetApp.getActiveSheet();
  const forbiddenCharacters = [";", " ", ":", "(", ")"];
  const targetColumn = 2; // ここで対象の列を指定します

  const values = getDataValues(sheet, targetColumn);

  for (let row = 1; row <= values.length; row++) {
    const value = values[row - 1];
    for (const char of forbiddenCharacters) {
      if (value.includes(char)) {
        sheet.getRange(row, targetColumn).setBackground("red");
        sheet.getRange(row, targetColumn).setComment(`文字 '${char}' は使えません`);
        break;
      } else {
        sheet.getRange(row, targetColumn).setBackground(null);
        sheet.getRange(row, targetColumn).setComment(null);
      }
    }
  }
}

// function showDialog(message: string):void {
//   var output = HtmlService.createTemplateFromFile('src/index');
//   var ss = SpreadsheetApp.getActiveSpreadsheet();
//   var html = output.evaluate().setSandboxMode(HtmlService.SandboxMode.IFRAME)
//              .setWidth(500)
//              .setHeight(300)
//              .setTitle('モーダルウィンドウテスト');
//   ss.show(html);    //メッセージボックスとしてを表示する
// }

function exportToCSV(): void {
  validateCellContents();
  const sheet = SpreadsheetApp.getActiveSheet();
  const lastRow = sheet.getLastRow();
  
  // A列とB列のインデックス（1から始まる）
  const columnAIndex = 1;
  const columnBIndex = 2;
  
  // A列とB列の存在を確認
  const range = sheet.getRange(1, columnAIndex, lastRow, columnBIndex);
  const values = range.getValues();

  for (let row = 0; row < values.length; row++) {
    const [valueA, valueB] = values[row];
    if (valueA === "" || valueB === "") {
      throw new Error(`エラー: A列とB列のセルが対応していません。行: ${row + 1}`);
    }
  }

  // エラーチェック：背景色が赤のセルがあるか確認
  const backgrounds = range.getBackgrounds();
  for (let row = 0; row < backgrounds.length; row++) {
    const rowBackgrounds = backgrounds[row];
    for (let col = 0; col < rowBackgrounds.length; col++) {
      const cellBackground = rowBackgrounds[col];
      if (cellBackground === "#ff0000") {
        throw new Error(`エラー: 背景色が赤のセルが存在します。行: ${row + 1}、列: ${col + 1}`);
      }
    }
  }

  const csvContent = values.map(row => row.join(",")).join("\n");

  console.log(csvContent);

  // CSVファイルの作成と保存
/*   const fileName = "data.csv";
  const mimeType = "text/csv";
  const fileBlob = Utilities.newBlob(csvContent, mimeType, fileName);
  const folder = DriveApp.getFolderById(destinationFolderId);
  folder.createFile(fileBlob); */
}