#!/bin/sh

# 経過したファイルを削除するディレクトリを環境変数から取得
DIRECTORIES="${LOG_DIRECTORIES}"
# 日数の環境変数を取得
DAYS="${LOG_DAYS}"

# 指定した日数以上経過したファイルを削除
for directory in $DIRECTORIES; do
    find "$directory" -type f -name "*.*" -mtime +${DAYS} -exec rm -f {} \;
done
