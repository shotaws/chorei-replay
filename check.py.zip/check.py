import socket
import ssl

# 確認したいドメインのリスト
domains = ["mail.google.com", "store.google.com", "play.google.com"]

# 確認したいワイルドカード証明書のパターン
wildcard_pattern = "*.google.com"

for domain in domains:
    try:
        # sslで証明書を取得
        ctx = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=5) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()

        # Common Name (CN)とSubject Alternative Name (SAN)を抽出
        cn = dict(cert["subject"][0])["commonName"]
        san = [alt[4:] for alt in dict(cert["subjectAltName"]) if alt.startswith("DNS:")]
        # print(f"cn: {cn}")
        # print(f"san: {san}")

        # 特定のワイルドカード証明書のパターンと一致するか確認
        if wildcard_pattern in cn or wildcard_pattern in san:
            print(f"{domain}: ワイルドカード証明書 '{wildcard_pattern}' が使用されています。")
        else:
            print(f"{domain}: ワイルドカード証明書 '{wildcard_pattern}' は使用されていません。")
    except socket.timeout:
        print(f"{domain}: 接続がタイムアウトしました。")
    except ssl.SSLError as e:
        print(f"{domain}: SSLエラー - {e}")
    except Exception as e:
        print(f"{domain}: 予期しないエラー - {e}")
