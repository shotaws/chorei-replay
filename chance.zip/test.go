package main

import (
	"context"
	"fmt"
	"log"
	"sync"
	"time"

	"golang.org/x/sync/errgroup"
)

type Data struct {
	TransactionId string
	UserId        string
	Point         int
}

func process(data *Data) error {
	fmt.Printf("transactionId = %s Id = %s Point = %d\n", data.TransactionId, data.UserId, data.Point)
	time.Sleep(500 * time.Millisecond)
	// NOTE: 意図的に失敗させてみる
	if data.TransactionId == "t001" || data.TransactionId == "t004" || data.TransactionId == "t007" {
		return fmt.Errorf("error test transactionId = %s Id = %s Point = %d", data.TransactionId, data.UserId, data.Point)
	}
	return nil
}

func main() {
	eg, _ := errgroup.WithContext(context.Background())

	// NOTE: サンプル
	data := []*Data{
		{"t001", "id00001", 1},
		{"t002", "id00002", 1},
		{"t003", "id00003", 1},
		{"t004", "id00004", 1},
		{"t005", "id00005", 100},
		{"t006", "id00006", 1},
		{"t007", "id00007", 1},
		{"t008", "id00008", 100},
		{"t009", "id00009", 1},
		{"t010", "id00010", 1},
		{"t011", "id00011", 1},
		{"t012", "id00012", 1},
		{"t013", "id00013", 1},
		{"t014", "id00014", 1},
		{"t015", "id00015", 1},
		{"t016", "id00016", 1},
		{"t017", "id00017", 1},
		{"t018", "id00018", 1},
		{"t019", "id00019", 1},
		{"t020", "id00020", 1},
		{"t021", "id00021", 1},
		{"t022", "id00022", 10000},
		{"t023", "id00023", 1},
		{"t024", "id00024", 1},
		{"t025", "id00025", 1},
		{"t026", "id00026", 1},
		{"t027", "id00027", 1},
		{"t028", "id00028", 1},
		{"t029", "id00029", 1},
		{"t030", "id00030", 1},
		{"t031", "id00031", 1},
		{"t032", "id00032", 1},
		{"t033", "id00033", 1},
		{"t034", "id00034", 1},
		{"t035", "id00035", 100},
		{"t036", "id00036", 1},
		{"t037", "id00037", 1},
		{"t038", "id00038", 1},
		{"t039", "id00039", 1},
		{"t040", "id00040", 1},
		{"t041", "id00041", 1},
		{"t042", "id00042", 1},
		{"t043", "id00043", 1},
		{"t044", "id00044", 1},
		{"t045", "id00045", 1},
		{"t046", "id00046", 1},
		{"t047", "id00047", 1},
		{"t048", "id00048", 1},
		{"t049", "id00049", 1},
		{"t050", "id00050", 1},
		{"t051", "id00051", 1},
		{"t052", "id00052", 1},
		{"t053", "id00053", 1},
		{"t054", "id00054", 1},
		{"t055", "id00055", 1},
		{"t056", "id00056", 1},
		{"t057", "id00057", 1},
		{"t058", "id00058", 1},
		{"t059", "id00059", 1},
		{"t060", "id00060", 1},
		{"t061", "id00061", 1},
		{"t062", "id00062", 1},
		{"t063", "id00063", 1},
		{"t064", "id00064", 1},
		{"t065", "id00065", 1},
		{"t066", "id00066", 1},
		{"t067", "id00067", 1},
		{"t068", "id00068", 1},
		{"t069", "id00069", 1},
		{"t070", "id00070", 1},
		{"t071", "id00071", 100},
		{"t072", "id00072", 1},
		{"t073", "id00073", 1},
		{"t074", "id00074", 1},
		{"t075", "id00075", 1},
		{"t076", "id00076", 1},
		{"t077", "id00077", 1},
		{"t078", "id00078", 1},
		{"t079", "id00079", 1},
		{"t080", "id00080", 1},
		{"t081", "id00081", 1},
		{"t082", "id00082", 1},
		{"t083", "id00083", 1},
		{"t084", "id00084", 1},
		{"t085", "id00085", 1},
		{"t086", "id00086", 1},
		{"t087", "id00087", 1},
		{"t088", "id00088", 100},
		{"t089", "id00089", 1},
		{"t090", "id00090", 1},
		{"t091", "id00091", 1},
		{"t092", "id00092", 1},
		{"t093", "id00093", 1},
		{"t094", "id00094", 1},
		{"t095", "id00095", 1},
		{"t096", "id00096", 1},
		{"t097", "id00097", 1},
		{"t098", "id00098", 100},
		{"t099", "id00099", 1},
		{"t100", "id00100", 1},
	}

	newArr := []Data{}    // NOTE: 失敗したデータ
	mutex := sync.Mutex{} // NOTE: Appendする際に排他制御が必要であるため

	eg.SetLimit(10) // NOTE: 同時上限
	for i := 0; i < 100; i++ {
		val := i // NOTE: https://qiita.com/sudix/items/67d4cad08fe88dcb9a6d
		eg.Go(func() error {
			if err := process(data[val]); err != nil {
				// NOTE: https://zenn.dev/aikizoku/articles/golang-goroutine
				mutex.Lock()
				newArr = append(newArr, *data[val])
				mutex.Unlock()
				return err
			}
			return nil
		})
	}

	// NOTE: errには最初にエラーを起こしたデータが入ってくる
	// NOTE: eg.Wait()を使わないとすべてのgoroutineが終了しない状態で後続の処理が動いてしまう可能性がある
	if err := eg.Wait(); err != nil {
		log.Fatal("失敗したデータがあります")
	}

	// NOTE: 失敗したデータを表示
	for i := 0; i < len(newArr); i++ {
		fmt.Println(newArr[i].TransactionId, newArr[i].UserId, newArr[i].Point)
	}
}
