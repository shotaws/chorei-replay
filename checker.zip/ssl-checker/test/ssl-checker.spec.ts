import * as cdk from "aws-cdk-lib";
import { Template } from "aws-cdk-lib/assertions";
import { SslCheckerStack } from "../lib/ssl-checker-stack";
import { EnvironmentType, getConfig } from "../lib/context";

// NOTE: https://qiita.com/marumeru/items/22882d4a1d524eec1788

// NOTE: 開発スタックとテンプレート作成
const getTestTemplate = (env: EnvironmentType): cdk.assertions.Template => {
  const app = new cdk.App();
  const config = getConfig(env);

  const stack = new SslCheckerStack(app, `testStac${env}`, {
    config,
  });

  return Template.fromStack(stack);
};

// NOTE: 全環境で同じテストを定義
const testSameInAllEnv = (template: cdk.assertions.Template) => {
  test("作成するLambdaは1つであること", () => {
    template.resourceCountIs("AWS::Lambda::Function", 1);
  });

  describe("「SSLChecker-xxx」のテスト", (): void => {
    test("Runtime（言語）の設定が「nodejs18.x」であること", () => {
      template.hasResourceProperties("AWS::Lambda::Function", {
        Runtime: "nodejs18.x",
      });
    });

    test("handler（実行コード）の設定が「sslChecker.handler」であること", () => {
      template.hasResourceProperties("AWS::Lambda::Function", {
        Handler: "sslChecker.handler",
      });
    });

    test("Description(説明)の設定が「SSL証明書を確認するLambda」であること", () => {
      template.hasResourceProperties("AWS::Lambda::Function", {
        Description: "SSL証明書を確認するLambda",
      });
    });

    test("Lambdaの関数実行タイムアウト時間が「30秒」であること", () => {
      template.hasResourceProperties("AWS::Lambda::Function", {
        Timeout: 30,
      });
    });
  });
};

// NOTE: テスト実行
const templateDev = getTestTemplate("dev");
describe("開発環境のテスト", (): void => {
  // NOTE: 共通のテスト
  testSameInAllEnv(templateDev);

  // NOTE: 環境ごとのテストを定義
  test("開発環境はLambda名が「SSLChecker-dev」であること", () => {
    templateDev.hasResourceProperties("AWS::Lambda::Function", {
      FunctionName: "SSLChecker-dev",
    });
  });
});

const templateStg = getTestTemplate("stg");

describe("検証環境のテスト", (): void => {
  // NOTE: 共通のテスト
  testSameInAllEnv(templateStg);

  // NOTE: 環境ごとのテストを定義
  test("検証環境はLambda名が「SSLChecker-stg」であること", () => {
    templateStg.hasResourceProperties("AWS::Lambda::Function", {
      FunctionName: "SSLChecker-stg",
    });
  });
});

const templateProd = getTestTemplate("prod");

describe("本番環境のテスト", (): void => {
  // NOTE: 共通のテスト
  testSameInAllEnv(templateProd);

  // NOTE: 環境ごとのテストを定義
  test("本番環境はLambda名が「SSLChecker-prod」であること", () => {
    templateProd.hasResourceProperties("AWS::Lambda::Function", {
      FunctionName: "SSLChecker-prod",
    });
  });
});