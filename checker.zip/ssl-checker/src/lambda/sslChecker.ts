import { Context } from "aws-lambda";
import * as https from "https";
import { TLSSocket } from "tls";
import { GetParameterCommand, SSMClient } from "@aws-sdk/client-ssm";

const ssmClient = new SSMClient({});

async function fetchDomainListFromParameterStore(): Promise<string[]> {
  const paramName = (process.env.PARAMETER_STORE || "") // Replace with your actual parameter name

  try {
    const response = await ssmClient.send(
      new GetParameterCommand({ Name: paramName })
    );

    if (response.Parameter && response.Parameter.Value) {
      return response.Parameter.Value.split(",");
    }
  } catch (error) {
    console.error("Error fetching domain list from Parameter Store:", error);
  }

  return [];
}

export async function handler(_event: undefined, _context: Context): Promise<void> {
  const domains = (process.env.DOMAINS || "").split(",");
  for (const domain of domains) {
    await processDomain(domain.trim());
  }
}

async function processDomain(domain: string) {
  try {
    const sslInfo = await getSslInfo(domain);

    const currentDate = new Date();
    const daysRemaining = Math.floor((sslInfo.valid_to - currentDate.getTime()) / (1000 * 60 * 60 * 24));

    if (daysRemaining <= 30) {
      console.log(`SSL certificate for domain '${domain}' will expire in ${daysRemaining} days.`);
    }

  } catch (error) {
    console.error(`An error occurred while checking SSL certificate for domain '${domain}':`, error);
    throw error;
  }
}

function getSslInfo(domain: string): Promise<{ valid_to: number }> {
  return new Promise((resolve, reject) => {
    const req = https.request(
      {
        hostname: domain,
        port: 443,
        method: "HEAD",
        rejectUnauthorized: false,
      },
      (res) => {
        const { valid_to } = (res.socket as TLSSocket).getPeerCertificate();
        if (valid_to) {
          resolve({ valid_to: new Date(valid_to).getTime() });
        } else {
          reject(new Error("Unable to retrieve SSL certificate information."));
        }
      }
    );

    req.on("error", (error) => {
      reject(error);
    });

    req.end();
  });
}
