import { Stack, StackProps, Duration } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { Function, Runtime, AssetCode } from 'aws-cdk-lib/aws-lambda';
import { Rule, Schedule } from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
import { Config } from "../lib/context";

interface SslCheckerStackProps extends StackProps {
  config: Config;
}

export class SslCheckerStack extends Stack {
  constructor(scope: Construct, id: string, props: SslCheckerStackProps) {
    super(scope, id, props);

    const { envType } = props.config;

    // NOTE: Lambda function
    const sslCheckerLambda = new Function(this, `SSLChecker-${envType}`, {
      functionName: `SSLChecker-${envType}`,
      runtime: Runtime.NODEJS_18_X,
      handler: "sslChecker.handler",
      code: new AssetCode("src/lambda"),
      description: "SSL証明書を確認するLambda",
      timeout: Duration.seconds(30),
      environment: {
        PARAMETER_STORE: "/test/param1",
        DOMAINS: "example.com,example.org", // Replace with your actual domain list
      },
    });

    // NOTE: EventBridge rule
    const rule = new Rule(this, "SslCheckerRule", {
      schedule: Schedule.cron({ minute: "0", hour: "0" }), // Run once a day at midnight
    });

    // NOTE: Add Lambda function as a target of the EventBridge rule
    rule.addTarget(new targets.LambdaFunction(sslCheckerLambda));
  }
}
