export type EnvironmentType = "prod" | "dev" | "stg";

export type Config = {
  envSystemName: string;
  envType: EnvironmentType;
  envName: string;
};

export function getConfig(environmentType: EnvironmentType): Config {
  const systemName = "SSLChecker";

  switch (environmentType) {
    case "prod":
      return {
        envSystemName: `${systemName}-${environmentType}`,
        envType: environmentType,
        envName: "production",
      };
    case "stg":
      return {
        envSystemName: `${systemName}-${environmentType}`,
        envType: environmentType,
        envName: "staging",
      };
    case "dev":
      return {
        envSystemName: `${systemName}-${environmentType}`,
        envType: environmentType,
        envName: "develop",
      };
    default:
      throw new Error("Context value [Env] is invalid (use [prod] or [stg] or [dev]).");
  }
}
