

npx cdk synth --context Env=dev

npx cdk synth --context Env=stg

npx cdk synth --context Env=prod