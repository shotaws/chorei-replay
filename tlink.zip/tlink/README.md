## インストール
```
yarn
```

## 実行

```
yarn ts-node src/index.ts
```

## テスト
```
yarn jest
```

## 生成物
- success.txt
  - 200OKのリンク一覧
- failure.txt
  - それ以外のリンク一覧