module.exports = {
    preset: 'ts-jest',
    transformIgnorePatterns: ['/node_modules'],
};