import puppeteer from 'puppeteer';
import axios from 'axios';
import * as fs from 'fs/promises';

// NOTE: ページ内のリンクを抽出する関数
export async function extractLinks(url: string): Promise<string[]> {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.goto(url);
    
    const links = await page.evaluate(() => 
        Array.from(document.querySelectorAll('a')).map(anchor => anchor.href)
    );

    await browser.close();
    return links;
}

// NOTE: リンクをチェックする関数
export async function checkLinks(links: string[]): Promise<{url: string, status: number}[]> {
    const results: {url: string, status: number}[] = [];
    for (const link of links) {
        try {
            const response = await axios.get(link);
            results.push({ url: link, status: response.status });
        } catch (error) {
            if (axios.isAxiosError(error) && error.response) {
                results.push({ url: link, status: error.response.status });
            } else {
                results.push({ url: link, status: 0 });
            }
        }
    }
    return results;
}

// NOTE: 結果をファイルに出力する関数
export async function writeResults(results: {url: string, status: number}[], successFile: string, failureFile: string): Promise<void> {
    const successfulLinks = results.filter(result => result.status === 200).map(result => result.url);
    const failedLinks = results.filter(result => result.status !== 200).map(result => `${result.url} - ${result.status}`);

    await fs.writeFile(successFile, successfulLinks.join('\n'), 'utf-8');
    await fs.writeFile(failureFile, failedLinks.join('\n'), 'utf-8');
}
