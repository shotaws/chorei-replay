import { extractLinks, checkLinks, writeResults } from './linkChecker';

const url = 'https://example.com';
// const url = 'https://www.iana.org/'

async function main() {
    try {
        const links = await extractLinks(url);
        console.log('Extracted Links:', links);

        const results = await checkLinks(links);
        console.log('Checked Links:', results);

        await writeResults(results, 'success.txt', 'failure.txt');
        console.log('Results written to files.');
    } catch (error) {
        console.error('Error:', error);
    }
}

main();
