import { extractLinks, checkLinks, writeResults } from '../src/linkChecker';
import fs from 'fs/promises';

jest.mock('puppeteer');
jest.mock('axios');
jest.mock('fs/promises');

const puppeteer = require('puppeteer');
const axios = require('axios');

describe('linkChecker', () => {
    const testHtml = `
        <html>
        <body>
            <a href="https://example.com/1">Link 1</a>
            <a href="https://example.com/2">Link 2</a>
            <a href="https://example.com/3">Link 3</a>
        </body>
        </html>
    `;
    const testUrl = 'https://example.com';

    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('should extract links from the page', async () => {
        const mockPage = {
            goto: jest.fn(),
            evaluate: jest.fn().mockResolvedValue([
                'https://example.com/1',
                'https://example.com/2',
                'https://example.com/3'
            ])
        };
        const mockBrowser = {
            newPage: jest.fn().mockResolvedValue(mockPage),
            close: jest.fn()
        };
        puppeteer.launch.mockResolvedValue(mockBrowser);

        const links = await extractLinks(testUrl);
        expect(links).toEqual([
            'https://example.com/1',
            'https://example.com/2',
            'https://example.com/3'
        ]);
        expect(puppeteer.launch).toHaveBeenCalled();
        expect(mockPage.goto).toHaveBeenCalledWith(testUrl);
        expect(mockBrowser.close).toHaveBeenCalled();
    });

    it('should check links and return their status', async () => {
        axios.get.mockImplementation((url: string) => {
            if (url === 'https://example.com/1') {
                return Promise.resolve({ status: 200 });
            } else if (url === 'https://example.com/2') {
                return Promise.resolve({ status: 404 });
            }
        });

        const links = [
            'https://example.com/1',
            'https://example.com/2'
        ];
        const results = await checkLinks(links);

        expect(results).toEqual([
            { url: 'https://example.com/1', status: 200 },
            { url: 'https://example.com/2', status: 404 },
        ]);
    });
});
