#!/bin/bash

# CSVファイルのパスを指定
CSV_FILE="/path/to/your/csvfile.csv"

# S3のバケット名とリージョンを指定
S3_BUCKET="your-s3-bucket-name"
S3_REGION="your-s3-region"

# 一時ファイルを作成
TEMP_FILE="$(mktemp)"

# 現在時刻を取得
CURRENT_TIME=$(date +"%Y-%m-%d %H:%M:%S")

# CSVファイルを1行ずつ読み込む
while IFS=, read -r FILENAME PUBLISH_TIME LAST_SENT_TIME; do
  # 現在時刻が公開開始時刻を超えていて、最終送信日時が公開開始時刻より前の場合、ファイルをS3に送信
  if [[ "$CURRENT_TIME" > "$PUBLISH_TIME" ]] && [[ "$LAST_SENT_TIME" < "$PUBLISH_TIME" ]]; then
    # S3にファイルをアップロード
    aws s3 cp "$FILENAME" "s3://$S3_BUCKET/$FILENAME" --region "$S3_REGION"
    # 最終送信日時を現在時刻に更新
    LAST_SENT_TIME="$CURRENT_TIME"
  fi
  # 一時ファイルに更新された行を書き込む
  echo "$FILENAME,$PUBLISH_TIME,$LAST_SENT_TIME" >> "$TEMP_FILE"
done < "$CSV_FILE"

# 元のCSVファイルを一時ファイルで置き換える
mv "$TEMP_FILE" "$CSV_FILE"
