#!/bin/bash

# CSVファイルのパスを指定
CSV_FILE="/path/to/your/csvfile.csv"
SENT_HISTORY_FILE="/path/to/your/sent_history.csv"

# S3のバケット名とリージョンを指定
S3_BUCKET="your-s3-bucket-name"
S3_REGION="your-s3-region"

# 現在時刻を取得
CURRENT_TIME=$(date +"%Y-%m-%d %H:%M:%S")

# 送信履歴ファイルが存在しない場合、新規作成
if [ ! -f "$SENT_HISTORY_FILE" ]; then
  touch "$SENT_HISTORY_FILE"
fi

# CSVファイルを処理
while IFS=, read -r FILENAME PUBLISH_TIME; do
  # 送信履歴ファイルから該当ファイル名の最終送信日時を取得
  LAST_SENT_TIME=$(grep "^$FILENAME," "$SENT_HISTORY_FILE" | cut -d, -f2)

  # 現在時刻が公開開始時刻を超えていて、最終送信日時が空か公開開始時刻より前の場合、ファイルをS3に送信
  if [[ "$CURRENT_TIME" > "$PUBLISH_TIME" ]] && ([[ -z "$LAST_SENT_TIME" ]] || [[ "$LAST_SENT_TIME" < "$PUBLISH_TIME" ]]); then
    # S3にファイルをアップロード
    aws s3 cp "$FILENAME" "s3://$S3_BUCKET/$FILENAME" --region "$S3_REGION"
    # 最終送信日時を現在時刻に更新
    LAST_SENT_TIME="$CURRENT_TIME"
    # 送信履歴ファイルを更新
    if grep -q "^$FILENAME," "$SENT_HISTORY_FILE"; then
      sed -i "s/^$FILENAME,.*/$FILENAME,$LAST_SENT_TIME/" "$SENT_HISTORY_FILE"
    else
      echo "$FILENAME,$LAST_SENT_TIME" >> "$SENT_HISTORY_FILE"
    fi
  fi
done < "$CSV_FILE"

# CSVファイルから削除されたサービスの送信履歴を削除
while IFS=, read -r FILENAME LAST_SENT_TIME; do
  # CSVファイルに該当ファイル名が存在しない場合、送信履歴ファイルから削除
  if ! grep -q "^$FILENAME," "$CSV_FILE"; then
    sed -i "/^$FILENAME,/d" "$SENT_HISTORY_FILE"
  fi
done < "$SENT_HISTORY_FILE"