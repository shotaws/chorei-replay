ID/PWは適当です。

batch_other : 別のcsvで送信履歴

batch_overwrite.sh: 同一csvに送信履歴